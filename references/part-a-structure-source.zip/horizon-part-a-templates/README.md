# Horizon Europe RIA — Part A structural template (2026 reference)

This project reconstructs the *administrative form* (Part A) in the supplied
`Proposal-SEP-211303496.pdf`, **PDF pages 1–202** (not Part B, which starts on
PDF page 203). It is a working **drafting/coordination representation**,
not an export format that can replace the Funding & Tenders Portal online
Part A. The portal remains the system of record; form configuration can
vary by call and version.

## Architecture and responsibility

Exactly **one `.tex` source file per participating organisation**, with the
canonical name `partners/partner-N-ACRO-admin-form.tex`, where:

* `N` is the **unpadded** positive participant number, assigned by the portal
  (examples: `1`, `2`, `12`), and
* `ACRO` is the partner acronym, uppercase ASCII letters/digits/hyphens
  (examples: `UNIBO`, `UU`, `CNRS`). It must match `organisation.short_name`.

| Source | Scope | Data represented |
|---|---|---|
| `part-a-consortium.tex` | consortium/coordinator | general proposal information, nine declarations |
| `part-a-partner.tex` | consortium assembly | imports the ordered partner manifest in participant mode |
| `partners/partner-1-UNIBO-admin-form.tex` | **partner 1 (only source)** | organisation, departments, links, contacts, researchers, roles, achievements, projects, equipment, GEP **and that partner's budget row** |
| `partners/participants.tex` | consortium assembly | single ordered manifest shared by the participant and budget passes |
| `part-a-budget.tex` | consortium assembly | re-imports the same partner files in budget mode (no separate per-partner budget files) |
| `part-a-inclusion.sty` | structure | controls which of the two partner data blocks is output; independent of styling |
| `part-a-ethics-security.tex` | consortium assembly | includes four separate ethics/security files |
| `ethics/ethics-questions.tex` | consortium | ethics question table (33 answers + page refs) |
| `ethics/ethics-self-assessment.tex` | consortium | two narrative fields |
| `ethics/security-questions.tex` | consortium | security question table (5 answers + page refs) |
| `ethics/security-self-assessment.tex` | consortium | security narrative |
| `schemas/fields.json` | machine-readable | field IDs, types, restrictions, source pages, confidence |
| `schemas/questions.json` | machine-readable | questions, stable keys, groupings, inferred parent-child structure |
| `part-a-semantics.sty` | presentation adapter | minimal `AField`, `ARecord`, `AQuestion`, `ADeclaration` macros; replace for styling |

The structure of **every** partner file is the same, except that an affiliated
entity may omit the main-contact record (as observed in the PDF). Each partner
file has two semantic blocks:

```tex
\AParticipantData{%
  \subsection{Participant 1 -- UNIBO}
  \begin{ARecord}{participant}
    \AField{participant.number}{1}
    % ... participant information ...
  \end{ARecord}
}
\ABudgetData{%
  \begin{ARecord}{budget_row}
    \AField{budget.participant_number}{1}
    % ... 16 budget fields ...
  \end{ARecord}
}
```

The main document includes `partners/participants.tex` **twice**, in two
exclusive modes. The same partner data is therefore rendered in the correct
administrative section without duplicating its source. No separate
`budget/partner-N.tex` files exist or should be created.

To add a participant:

```sh
python3 scripts/add_partner.py 2 UU
python3 scripts/add_partner.py 4 CNRS --role affiliated
make validate
make pdf
```

The script creates exactly one `.tex` file for that participant, copies the
complete template structure, replaces participant number and acronym,
and maintains `partners/participants.tex` in numeric order.

## Source PDF map (1-indexed PDF page numbers)

* pp. 1–3: General information / declarations. p. 2 includes project title,
  abstract, keywords, duration, and previous submission; p. 3 has nine declarations.
* pp. 4–5: List of participants, roles and country codes (25 entries in this example).
* pp. 6–14: Complete exemplar of one partner's organisational and staff information.
  This block repeats across pp. 15–193, with variable numbers of extra pages.
* pp. 194–195: Consolidated budget table (all participants plus TOTAL row).
* pp. 196–197: Ethics Issues Table and acknowledgement.
* pp. 198–200: Ethics self-assessment (two fields).
* p. 201: Security Issues Table + Security self-assessment.
* p. 202: Security footnotes.

## Observed and reverse-engineered constraints

**Character counts include spaces.** The PDF's abstract is 1,709 characters
when presentation line wraps are joined; `Remaining characters: 291`, proving
an effective 2,000-character budget for this field. The corresponding
5,000-character long-form limits are inferred from the other remaining
character counters, with small ambiguity over paragraph breaks introduced
by PDF extraction. The default validator counts visible text, not raw LaTeX
bytes, and does not fully emulate Portal rich-text processing.

| Field | Cardinality or limit | Evidence |
|---|---:|---|
| Abstract | 2,000 characters | p. 2 counter (+ exact reconstructed count) |
| Achievements | at most 5 per participant | p. 11 explicit |
| Achievement description | 500 characters | p. 11 explicit |
| Previous projects/activities | at most 5 | p. 11 explicit |
| Previous project/activity description | 500 characters | p. 11 explicit |
| Infrastructure/equipment description | 300 characters | p. 12 explicit |
| Other participant role text | 50 characters | p. 10 explicit |
| Previous submitted proposal reference | 6 or 9 digits | p. 2 explicit |
| Ethics dimension narrative | 5,000 characters | pp. 198–199 counter inferred |
| Ethics compliance narrative | 5,000 characters | pp. 199–200 counter inferred |
| Security national-restrictions details | 1,000 characters | p. 201 explicit |
| Security other-issues details | 1,000 characters | p. 201 explicit |
| Security self-assessment | 5,000 characters | p. 201 counter inferred |
| Title | `<`, `>`, `"`, `&` prohibited | p. 2 explicit |

**Unknowns:** The document alone does *not* establish the maximum lengths of
acronym, proposal title, free keywords, previous project names, infrastructure
names, department names, contact fields, ethics-specific details, or Part B
page-reference lists. Their `max_chars` in the schema is `null`, not guessed.
A similar distinction applies to portal-specific enumerations not visible in
the populated sample. Consult the actual online form for authoritative limits.

**Mandatory:** The PDF explicitly flags abstract, the main contact's first
name/last name/email, and nine declarations. Some other fields are marked
required in the schema only as a plausible completeness assumption, with the
confidence flag distinguishing the inference.

## Data types

* `boolean`: yes/no (template sentinel `unanswered`; `unconfirmed` for declarations).
* `enum`: coordinator/partner/affiliated; gender; researcher stage; researcher
  project role; organisation registry statuses.
* `multiselect`: 17 predefined participating-organisation roles, including
  `other`, with a conditional 50-character explanation.
* `controlled_vocabulary`: proposal fixed keyword and achievement type;
  choices not fully established by the submitted PDF.
* `identifier`: PIC (observed nine-digit), researcher identifier (ORCID
  format when applicable), prior-proposal reference (exactly 6 or 9 digits).
* `email`, `date`, `integer` (duration, participant index), `decimal` (EUR costs),
  `string`, `text` (length-limited long-form response).
* `array<record>`: departments, participant links, contacts, researchers,
  achievements, previous projects, equipment and budget rows.
* `question_with_pages`: yes/no plus optional Part B page reference(s) and,
  for some affirmative questions, conditional explanatory text.

## Budget semantics

Every participant, including any affiliated entity represented as its own
participant, has exactly one budget row **in that participant's admin-form file**. The observed table contains:

1. Personnel costs (EUR); subcontracting (EUR).
2. Purchase costs: travel/subsistence, equipment, other goods/works/services.
3. Internally invoiced goods/services (unit costs).
4. Indirect costs; total eligible costs; funding rate.
5. Maximum EU contribution to eligible costs; requested EU contribution;
   max grant amount.
6. Income generated by the action; financial contributions; own resources;
   total estimated income.

For the example's ordinary cost categories, `indirect = 25% × (personnel +
travel + equipment + other goods/works/services)` and
`eligible_total = personnel + subcontracting + travel + equipment + other +
internally_invoiced + indirect`. The example has 100% RIA rates, but the rate
remains a per-row field rather than being hard-coded. Other cost exclusions,
funding ceilings, rounding rules and portal-calculated maximums depend on the
call/beneficiary and should be verified in the portal. The TOTAL row aggregates
monetary amounts, **not funding rates**.

## Ethics/security structure

The ethics table includes nine group headings with **33 boolean questions**.
The security table includes three group headings with **five boolean questions**.
Each `\AQuestion{id}{label}{answer}{part_b_page_refs}` stores a stable field key,
answer and references. The visible sub-question hierarchy is encoded in
`schemas/questions.json`, with parentage explicitly marked as inferred from
indentation. In addition there are:

* Ethics confirmation (checkbox).
* Two independent ethics texts: (i) ethical dimension of objectives, method,
  impact; (ii) legislative/ethical compliance.
* Security text on national restrictions (if yes; max 1,000).
* Security text on other security issues (if yes; max 1,000).
* Security self-assessment (max 5,000).
* Free text for e.g. cross-border personal data and non-EU activities; the PDF
  confirms their existence but does not disclose their maximum length.

## Commands

```sh
make pdf        # compile self-contained structural preview: build/part-a.pdf
make validate   # validate typed values, max lengths and question catalogue
make budget-check  # check budget blocks within partner admin-form files; compute totals
make strict     # additionally reject empty mandatory fields (expected to fail when blank)
make test       # run parser/schema regression tests
make schema     # rebuild the field dictionary from existing TeX sources
make questions  # DESTRUCTIVE: regenerate blank questions from the static catalogue
```

Only `part-a-semantics.sty` controls visual presentation. Another agent can
replace it without changing IDs, field structure, record boundaries, or
conditional/character-limit metadata. The validation script deliberately
performs conservative text approximations for LaTeX-formatted input.
