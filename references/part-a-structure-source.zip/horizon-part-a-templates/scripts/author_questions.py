#!/usr/bin/env python3
"""Source catalogue for questions copied from the 2026 PDF; runs at authoring time."""
import json
from pathlib import Path
R = Path(__file__).resolve().parents[1]
# The keys are deliberately stable, for cross-references and portal transcription.
Q = [
# Ethics 1
('ethics.hesc',1,'Does this activity involve Human Embryonic Stem Cells (hESCs)?',None),
('ethics.embryos',1,'Does this activity involve the use of human embryos?',None),
# Ethics 2
('ethics.humans.participants',2,'Does this activity involve human participants?',None),
('ethics.humans.nonmedical_volunteers',2,'Are they volunteers for non medical studies (e.g. social or human sciences research)?','ethics.humans.participants'),
('ethics.humans.healthy_volunteers',2,'Are they healthy volunteers for medical studies?','ethics.humans.participants'),
('ethics.humans.patients',2,'Are they patients for medical studies?','ethics.humans.participants'),
('ethics.humans.vulnerable',2,'Are they potentially vulnerable individuals or groups?','ethics.humans.participants'),
('ethics.humans.minors',2,'Are they children/minors?','ethics.humans.participants'),
('ethics.humans.no_consent',2,'Are they other persons unable to give informed consent?','ethics.humans.participants'),
('ethics.humans.interventions',2,'Does this activity involve interventions (physical also including imaging technology, behavioural treatments, etc.) on the study participants?',None),
('ethics.humans.clinical_study',2,'Does this activity involve conducting a clinical study as defined by the Clinical Trial Regulation (EU 536/2014)? (using pharmaceuticals, biologicals, radiopharmaceuticals, or advanced therapy medicinal products)',None),
# Ethics 3
('ethics.cells_tissues',3,'Does this activity involve the use of human cells or tissues?',None),
# Ethics 4
('ethics.data.personal',4,'Does this activity involve processing of personal data?',None),
('ethics.data.special',4,'Does it involve the processing of special categories of personal data (e.g.: genetic, biometric and health data, sexual lifestyle, ethnicity, political opinion, religious or philosophical beliefs)?','ethics.data.personal'),
('ethics.data.genetic_biometric_health',4,'Does it involve processing of genetic, biometric or health data?','ethics.data.special'),
('ethics.data.profiling',4,'Does it involve profiling, systematic monitoring of individuals, or processing of large scale of special categories of data or intrusive methods of data processing (such as, surveillance, geolocation tracking etc.)?','ethics.data.personal'),
('ethics.data.further_processing',4,'Does this activity involve further processing of previously collected personal data (including use of preexisting data sets or sources, merging existing data sets)?',None),
('ethics.data.export',4,'Is it planned to export personal data from the EU to non-EU countries?',None),
('ethics.data.import',4,'Is it planned to import personal data from non-EU countries into the EU or from a non-EU country to another non-EU country?',None),
('ethics.data.criminal',4,'Does this activity involve the processing of personal data related to criminal convictions or offences?',None),
# Ethics 5
('ethics.animals',5,'Does this activity involve animals?',None),
# Ethics 6
('ethics.non_eu.activities',6,'Will some of the activities be carried out in non-EU countries?',None),
('ethics.non_eu.ethics_issues',6,'In case non-EU countries are involved, do the activities undertaken in these countries raise potential ethics issues?','ethics.non_eu.activities'),
('ethics.non_eu.local_resources',6,'It is planned to use local resources (e.g. animal and/or human tissue samples, genetic material, live animals, human remains, materials of historical value, endangered fauna or flora samples, etc.)?','ethics.non_eu.activities'),
('ethics.non_eu.import_material',6,'Is it planned to import any material (other than data) from non-EU countries into the EU or from a non-EU country to another non-EU country? For data imports, see section 4.','ethics.non_eu.activities'),
('ethics.non_eu.export_material',6,'Is it planned to export any material (other than data) from the EU to non-EU countries? For data exports, see section 4.','ethics.non_eu.activities'),
('ethics.non_eu.low_income',6,'Does this activity involve low and/or lower middle income countries (if yes, detail the benefit-sharing actions planned in the self-assessment)?','ethics.non_eu.activities'),
('ethics.non_eu.individual_risk',6,'Could the situation in the country put the individuals taking part in the activity at risk?','ethics.non_eu.activities'),
# Ethics 7
('ethics.environment.harm',7,'Does this activity involve the use of substances or processes that may cause harm to the environment, to animals or plants (during the implementation of the activity or further to the use of the results, as a possible impact)?',None),
('ethics.environment.endangered',7,'Does this activity deal with endangered fauna and/or flora / protected areas?',None),
('ethics.environment.human_harm',7,'Does this activity involve the use of substances or processes that may cause harm to humans, including those performing the activity (during the implementation of the activity or further to the use of the results, as a possible impact)?',None),
# Ethics 8/9
('ethics.ai',8,'Does this activity involve the development, deployment and/or use of Artificial Intelligence-based systems?',None),
('ethics.other',9,'Are there any other ethics issues that should be taken into consideration?',None),
]
S = [
('security.eu_classified_info',1,'Does this activity involve information and/or materials requiring protection against unauthorised disclosure (EUCI)?'),
('security.non_eu_access',1,'Does this activity involve non-EU countries which need to have access to EUCI?'),
('security.misuse',2,'Does this activity have the potential for misuse of results?'),
('security.national_restrictions',3,'Does this activity involve information and/or materials subject to national security restrictions?'),
('security.other',3,'Are there any other security issues that should be taken into consideration?'),
]
ethics=[{'id':id,'group':group,'label':label,'type':'boolean','parent':parent,'part_a_pages':[196,197],'part_b_pages':[],'answer':None,'evidence':'observed'} for id,group,label,parent in Q]
security=[{'id':id,'group':group,'label':label,'type':'boolean','part_a_pages':[201],'part_b_pages':[],'answer':None,'evidence':'observed'} for id,group,label in S]
questions={'ethics':ethics,'security':security,'metadata':{'source':'Proposal-SEP-211303496.pdf','source_part_a_version':'Horizon Europe ver 1.00 20241022','reference':'pages 196-197 and 201 (PDF pages, 1-indexed)','note':'Parent-child visibility inferred from indentation; page references point to Part B, not administrative-form pages.'}}
(R/'schemas'/'questions.json').write_text(json.dumps(questions,indent=2,ensure_ascii=False)+'\n')

def texescape(s):
 for a,b in [ ('\\','\\textbackslash{}'),('&','\\&'),('%','\\%'),('#','\\#'),('_','\\_'),('{','\\{'),('}','\\}') ]:
  # Don't actually escape braces introduced by the backslash substitution; titles here have no backslashes.
  s=s.replace(a,b)
 return s
sections=['Human Embryonic Stem Cells and Human Embryos','Humans','Human Cells / Tissues','Personal Data','Animals','Non-EU Countries','Environment, Health and Safety','Artificial Intelligence','Other Ethics Issues']
lines=['% Auto-generated from schemas/questions.json; edit answers and page refs after generation.','% Syntax: \\AQuestion{stable-key}{question}{yes|no|unanswered}{Part-B page references}', '\\section{Ethics and security}', '\\subsection{Ethics Issues Table}']
prev=0
for item in ethics:
 if item['group']!=prev:
  prev=item['group'];lines.append(f'\\subsubsection{{{prev}. {sections[prev-1]}}}')
 lines.append('\\AQuestion{%s}{%s}{unanswered}{}' %(item['id'],texescape(item['label'])))
 if item['id']=='ethics.data.import': lines.append('\\AField{ethics.data.import.details}{}')
 if item['id']=='ethics.non_eu.activities': lines.append('\\AField{ethics.non_eu.activities.details}{}')
lines += ['\\AField{ethics.confirmation}{unconfirmed}', '\\subsection{Ethics self-assessment}', '\\subsubsection{Ethical dimension of the objectives, methodology and likely impact}', '\\AField{ethics.self_assessment.dimension}{}', '\\subsubsection{Compliance with ethical principles and relevant legislations}', '\\AField{ethics.self_assessment.compliance}{}', '\\subsection{Security Issues Table}']
prev=0
for item in security:
 if item['group']!=prev:
  prev=item['group']; lines.append('\\subsubsection{%s. %s}'%(prev,['EU Classified Information (EUCI)','Misuse','Other Security Issues'][prev-1]))
 lines.append('\\AQuestion{%s}{%s}{unanswered}{}'%(item['id'],texescape(item['label'])))
 if item['id'] in ('security.national_restrictions','security.other'):
  lines.append('\\AField{%s.details}{}'%item['id'])
lines += ['\\subsection{Security self-assessment}', '\\AField{security.self_assessment}{}']

# Split the questionnaire and narrative responses into distinct editable sources.
def part(start,finish=None):
 i=next(k for k,v in enumerate(lines) if v==start)
 j=next((k for k,v in enumerate(lines[i+1:],i+1) if v==finish),len(lines)) if finish else len(lines)
 return lines[i:j]
sections={
 'ethics-questions.tex':part('\\subsection{Ethics Issues Table}','\\subsection{Ethics self-assessment}'),
 'ethics-self-assessment.tex':part('\\subsection{Ethics self-assessment}','\\subsection{Security Issues Table}'),
 'security-questions.tex':part('\\subsection{Security Issues Table}','\\subsection{Security self-assessment}'),
 'security-self-assessment.tex':part('\\subsection{Security self-assessment}'),
}
(R/'ethics').mkdir(exist_ok=True)
for file,content in sections.items():
 (R/'ethics'/file).write_text('% Reconstructed from administrative Part A; edit field answers here.\n'+'\n'.join(content)+'\n')
(R/'part-a-ethics-security.tex').write_text('\\section{Ethics and security}\n'+''.join('\\input{ethics/'+f+'}\n' for f in sections))

print('Generated',len(ethics),'ethics and',len(security),'security questions.')
