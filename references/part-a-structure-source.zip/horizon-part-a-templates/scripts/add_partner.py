#!/usr/bin/env python3
"""Add one complete partner admin-form file and insert it into the ordered manifest."""
from __future__ import annotations
import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARTNERS = ROOT / 'partners'
NAME = re.compile(r'^partner-([1-9][0-9]*)-([A-Z0-9]+(?:-[A-Z0-9]+)*)-admin-form\.tex$')
INCLUDE = re.compile(r'^\\input\{partners/(partner-[^}]+-admin-form\.tex)\}$', re.M)


def format_name(number: int, acronym: str) -> str:
    if number < 1:
        raise ValueError('participant number must be >= 1')
    acronym = acronym.upper()
    if not re.fullmatch(r'[A-Z0-9]+(?:-[A-Z0-9]+)*', acronym):
        raise ValueError('acronym must contain ASCII letters, digits or internal hyphens')
    return f'partner-{number}-{acronym}-admin-form.tex'


def registered() -> list[tuple[int, str, Path]]:
    result = []
    for p in PARTNERS.glob('partner-*.tex'):
        m = NAME.fullmatch(p.name)
        if not m:
            raise ValueError(f'invalid partner filename: {p.name}')
        result.append((int(m.group(1)), m.group(2), p))
    return sorted(result)


def update_manifest() -> None:
    items = registered()
    numbers = [n for n, _, _ in items]
    if len(numbers) != len(set(numbers)):
        raise ValueError('duplicate participant number')
    body = '% Central ordered manifest; used in both participant and budget passes.\n'
    body += ''.join(f'\\input{{partners/{p.name}}}\n' for _, _, p in items)
    (PARTNERS / 'participants.tex').write_text(body, encoding='utf-8')


def add_partner(number: int, acronym: str, role: str = 'partner') -> Path:
    if role not in ('coordinator', 'partner', 'affiliated'):
        raise ValueError('role must be coordinator, partner, or affiliated')
    filename = format_name(number, acronym)
    acronym = acronym.upper()
    if any(n == number for n, _, _ in registered()):
        raise ValueError(f'participant number {number} already in use')
    new = PARTNERS / filename
    template = PARTNERS / 'partner-1-UNIBO-admin-form.tex'
    src = template.read_text(encoding='utf-8')
    src = src.replace('participant 1 (UNIBO)', f'participant {number} ({acronym})')
    src = src.replace('Participant 1 -- UNIBO', f'Participant {number} -- {acronym}')
    src = src.replace('\\AField{participant.number}{1}', f'\\AField{{participant.number}}{{{number}}}')
    src = src.replace('\\AField{participant.role}{coordinator}', f'\\AField{{participant.role}}{{{role}}}')
    src = src.replace('\\AField{organisation.short_name}{UNIBO}', f'\\AField{{organisation.short_name}}{{{acronym}}}')
    src = src.replace('\\AField{budget.participant_number}{1}', f'\\AField{{budget.participant_number}}{{{number}}}')
    if role == 'affiliated':
        src = re.sub(r'\\subsubsection\{Main contact person\}.*?\\end\{ARecord\}',
                     '% Affiliated entity: no main contact required by the observed example.', src, flags=re.S)
    new.write_text(src, encoding='utf-8')
    update_manifest()
    return new


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('number', type=int, help='participant number (un-padded)')
    parser.add_argument('acronym', help='partner acronym, e.g. UU or CNRS')
    parser.add_argument('--role', choices=['coordinator', 'partner', 'affiliated'], default='partner')
    args = parser.parse_args()
    try:
        result = add_partner(args.number, args.acronym, args.role)
    except ValueError as exc:
        parser.error(str(exc))
    print(f'Created {result.relative_to(ROOT)}; updated partners/participants.tex')
