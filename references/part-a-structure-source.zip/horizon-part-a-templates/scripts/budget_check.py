#!/usr/bin/env python3
"""Check/populate the arithmetic implied by the observed budget table.

This is a transparent advisory check for standard cost categories; legal funding
eligibility and portal rounding/special categories remain authoritative.
"""
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from validate import ROOT,args_of,plain_text

D=Decimal
CENT=D('0.01')
INPUT=['personnel_eur','subcontracting_eur','travel_subsistence_eur','equipment_eur','other_goods_works_services_eur','internally_invoiced_eur']
ROWS=[]

def amt(value):
    return D(value).quantize(CENT,rounding=ROUND_HALF_UP)

def check():
    nerrors=0
    summary=defaultdict(lambda:D('0.00'))
    for p in sorted((ROOT/'partners').glob('partner-*-admin-form.tex')):
        src=p.read_text(encoding='utf-8')
        row={k.removeprefix('budget.'):plain_text(v) for (k,v),_ in args_of(src,'AField',2)}
        if not any(row.get(k) for k in INPUT):
            print(f'{p.name}: awaiting budget inputs');continue
        missing=[k for k in INPUT if not row.get(k)]
        if missing:
            print(f'{p.name}: incomplete numeric inputs: {missing}');nerrors+=1;continue
        try:
            vals={k:amt(row[k]) for k in INPUT}
            rate=D(row.get('funding_rate_pct',''))
            if not rate.is_finite() or not D('0')<=rate<=D('100'):raise InvalidOperation
        except (InvalidOperation,ValueError):
            print(f'{p.name}: invalid amount/funding rate');nerrors+=1;continue
        # Standard Horizon 25% indirect flat-rate base in this PDF example.
        indirect=amt(D('0.25')*(vals['personnel_eur']+vals['travel_subsistence_eur']+vals['equipment_eur']+vals['other_goods_works_services_eur']))
        eligible=sum(vals.values(),indirect)
        max_eu=amt(eligible*rate/D('100'))
        expected={'indirect_eur':indirect,'total_eligible_eur':eligible,'maximum_eu_for_eligible_eur':max_eu}
        for k,v in expected.items():
            if row.get(k):
                if amt(row[k])!=v:
                    print(f'{p.name}: MISMATCH {k}: source={row[k]}, implied={v}');nerrors+=1
            summary[k]+=v
        for k,v in vals.items():summary[k]+=v
        print(f'{p.name} participant {row.get("participant_number","?")}: indirect={indirect} eligible={eligible} max EU={max_eu} at rate {rate}%')
        if row.get('requested_eu_eur'):
            requested=amt(row['requested_eu_eur'])
            if requested>max_eu:
                print(f'{p.name}: requested EU amount exceeds maximum EU on eligible costs');nerrors+=1
            components=['income_generated_eur','financial_contributions_eur','own_resources_eur']
            if all(row.get(k) for k in components):
                total_income=requested+sum((amt(row[k]) for k in components),D('0.00'))
                if row.get('total_estimated_income_eur') and amt(row['total_estimated_income_eur'])!=total_income:
                    print(f'{p.name}: MISMATCH total_estimated_income_eur: implied={total_income}');nerrors+=1
    if summary:
        print('Consortium monetary totals (computed from populated rows):')
        for k in INPUT+['indirect_eur','total_eligible_eur','maximum_eu_for_eligible_eur']:
            print(f'  {k}: {summary[k]}')
    return nerrors

if __name__=='__main__':raise SystemExit(bool(check()))
