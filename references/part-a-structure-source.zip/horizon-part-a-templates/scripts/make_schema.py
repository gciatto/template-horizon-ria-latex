#!/usr/bin/env python3
"""Build source-indexed, deliberately conservative field-schema catalogue."""
import re,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
files=['part-a-consortium.tex'] + [str(p.relative_to(R)) for p in sorted((R/'partners').glob('partner-*-admin-form.tex'))] + ['ethics/ethics-questions.tex','ethics/ethics-self-assessment.tex','ethics/security-questions.tex','ethics/security-self-assessment.tex']
entries={}
for file in files:
 for f in re.findall(r'\\AField\{([^{}]+)\}\{', (R/file).read_text()):
  if f in entries: continue
  scope = ('consortium' if f.startswith('proposal.') else
           'partner' if f.startswith(('participant.','organisation.','department.','link.','contact.','researcher.','achievement.','previous_project.','infrastructure.')) else
           'budget' if f.startswith('budget.') else 'ethics_security')
  if scope=='partner':
   source_by_prefix={'organisation.':[6],'department.':[7],'link.':[7],'contact.':[8],
                     'researcher.':[9],'achievement.':[11],'previous_project.':[11,12],
                     'infrastructure.':[12],'participant.':[4,5]}
   pages=next((v for prefix,v in source_by_prefix.items() if f.startswith(prefix)),[4])
  else:
   pages=[2,3] if scope=='consortium' else [194,195] if scope=='budget' else [196,197,198,199,200,201]
  entries[f]={'type':'string','scope':scope,'required':False,'source_pdf_pages':pages,'confidence':'observed_field','max_chars':None,'count_spaces':None}
def setfield(id,**kw):
 assert id in entries,id
 entries[id].update(kw)
def batch(ids,**kw):
 for id in ids.split():setfield(id,**kw)

batch('proposal.id proposal.call proposal.topic proposal.action_type proposal.model_grant_agreement', read_only=True)
setfield('proposal.id',type='identifier',pattern=r'^\d{9}$',confidence='inferred_validation')
setfield('proposal.action_type',type='enum',values=['HORIZON-RIA'],confidence='observed_value_only')
setfield('proposal.acronym',type='string',required=True,confidence='inferred_required')
setfield('proposal.title',type='string',required=True,forbidden_characters='< > " &'.replace(' ', ''),confidence='observed_invalid_characters_required_inferred')
setfield('proposal.duration_months',type='integer',minimum=1,confidence='inferred_positive_constraint')
setfield('proposal.fixed_keyword_1',type='controlled_vocabulary',confidence='observed_form_lookup')
setfield('proposal.free_keywords',type='string',confidence='observed_field')
setfield('proposal.abstract',type='text',max_chars=2000,count_spaces=True,required=True,source_pdf_pages=[2],confidence='reverse_engineered_exact_from_1709_plus_291')
setfield('proposal.submitted_similar_last_2y',type='boolean',confidence='observed')
setfield('proposal.previous_reference',type='identifier',pattern=r'^(\d{6}|\d{9})$',required_if={'field':'proposal.submitted_similar_last_2y','equals':'yes'},source_pdf_pages=[2],confidence='explicit_pdf')

setfield('participant.number',type='integer',minimum=1,required=True)
setfield('participant.role',type='enum',values=['coordinator','partner','affiliated'],required=True,source_pdf_pages=[4,5],confidence='observed_values')
setfield('organisation.pic',type='identifier',pattern=r'^\d{9}$',read_only=True,confidence='observed_9_digit_ids_pattern_inferred')
batch('organisation.legal_name organisation.country organisation.short_name',required=True,confidence='inferred_required')
batch('organisation.legal_person organisation.public_body organisation.non_profit organisation.international_organisation organisation.higher_education organisation.research_organisation', type='boolean',read_only=True,confidence='observed_read_only_registry')
setfield('organisation.sme_self_declared',type='boolean',read_only=True)
batch('organisation.sme_self_declaration_date organisation.sme_self_assessment_date organisation.sme_validation_date',type='date',format='DD/MM/YYYY',read_only=True)
batch('organisation.sme_self_assessment organisation.sme_validation',type='enum',values=['yes','no','unknown'],read_only=True,confidence='observed_unknown_no_values')
batch('department.not_applicable department.same_as_organisation_address contact.same_as_organisation_name contact.same_as_organisation_address',type='boolean')
setfield('link.participant_number',type='integer',minimum=1,confidence='inferred_referential')
setfield('contact.gender',type='enum',values=['woman','man','non_binary'],confidence='observed_options')
batch('contact.first_name contact.last_name contact.email',required=True,confidence='required_for_main_contact_only')
setfield('contact.email',type='email')
setfield('researcher.gender',type='enum',values=['woman','man','non_binary'])
setfield('researcher.email',type='email')
setfield('researcher.career_stage',type='enum',values=['A','B','C','D'],confidence='A_B_C_observed_D_inferred')
setfield('researcher.project_role',type='enum',values=['leading','team_member'],confidence='observed_values')
setfield('researcher.reference_identifier',type='identifier',pattern=r'^\d{4}-\d{4}-\d{4}-[\dX]{4}$',condition={'field':'researcher.identifier_type','equals':'ORCID ID'},confidence='ORCID_pattern_inferred')
roleopts=['project_management','communication_dissemination_engagement','research_technology_infrastructure','research_market_needs','civil_society_representative','policy_maker_regulator_standardisation','research_performer','technology_developer','testing_validation','prototyping_demonstration','ipr_management_technology_transfer','public_procurer','private_buyer','finance_provider','education_training','social_sciences_humanities','other']
setfield('participant.project_roles',type='multiselect',values=roleopts,source_pdf_pages=[10],confidence='observed')
setfield('participant.other_role_specification',type='string',max_chars=50,count_spaces=True,required_if={'field':'participant.project_roles','contains':'other'},source_pdf_pages=[10],confidence='explicit_pdf')
setfield('achievement.type',type='controlled_vocabulary',confidence='publication_software_observed_others_unknown')
setfield('achievement.description',type='text',max_chars=500,count_spaces=True,source_pdf_pages=[11],confidence='explicit_pdf')
setfield('previous_project.description',type='text',max_chars=500,count_spaces=True,source_pdf_pages=[11,12],confidence='explicit_pdf')
setfield('infrastructure.description',type='text',max_chars=300,count_spaces=True,source_pdf_pages=[12],confidence='explicit_pdf')
setfield('participant.gep',type='boolean',source_pdf_pages=[14],confidence='observed')

money=[k for k in entries if k.startswith('budget.') and k.endswith('_eur')]
for k in money:setfield(k,type='decimal',minimum=0,unit='EUR',precision=2,confidence='inferred_numeric_validation')
setfield('budget.participant_number',type='integer',minimum=1)
setfield('budget.funding_rate_pct',type='decimal',minimum=0,maximum=100,unit='percent',confidence='observed_100_in_this_RIA_not_universal')
for k in ('budget.indirect_eur','budget.total_eligible_eur','budget.maximum_eu_for_eligible_eur','budget.max_grant_amount_eur','budget.total_estimated_income_eur'):
 setfield(k,calculated=True,confidence='derived_or_portal_calculated')
setfield('ethics.confirmation',type='boolean',required=True,source_pdf_pages=[197],confidence='observed_checkbox')
for k in ('ethics.self_assessment.dimension','ethics.self_assessment.compliance','security.self_assessment'):
 setfield(k,type='text',max_chars=5000,count_spaces=True,required_if={'field':'ethics.confirmation','equals':'yes'} if k.startswith('ethics.') else None,source_pdf_pages=[198,199,200] if k.startswith('ethics.') else [201],confidence='reverse_engineered_from_remaining_characters')
for k in ('security.national_restrictions.details','security.other.details'):
 setfield(k,type='text',max_chars=1000,count_spaces=True,required_if={'field':k.removesuffix('.details'),'equals':'yes'},source_pdf_pages=[201],confidence='explicit_pdf')
setfield('ethics.data.import.details',type='text',required_if={'field':'ethics.data.import','equals':'yes'},source_pdf_pages=[196],confidence='observed_conditional_textbox_limit_unknown')
setfield('ethics.non_eu.activities.details',type='text',required_if={'field':'ethics.non_eu.activities','equals':'yes'},source_pdf_pages=[197],confidence='observed_conditional_textbox_limit_unknown')

schema={
 '$schema':'https://json-schema.org/draft/2020-12/schema',
 'title':'Horizon Europe RIA Part A - reconstructed data dictionary',
 'meta':{
  'source':'Proposal-SEP-211303496.pdf', 'pages':'1-202 of 303',
  'form_version':'Horizon Europe ver 1.00 20241022',
  'coverage':'Admin form for HORIZON-RIA budget-based grant; do not generalise hard constraints to other calls without checking',
  'partner_file_pattern':'partners/partner-N-ACRO-admin-form.tex (N unpadded, ACRO uppercase)',
  'partner_file_contents':'Participant fields and budget row in the same TeX file, included in two mutually exclusive passes',
  'counting_policy':'Maximum character limits count spaces and paragraph separators; TeX source validator approximates portal text after minimal unescaping.',
  'confidence_semantics':'explicit_pdf = printed constraint; reverse_engineered = inferred from counter and extracted content; observed = value seen; inferred = generic check only; unknown max_chars null = no limit established.'
 },
 'record_limits':{'achievement':{'maximum':5,'source_pdf_pages':[11]},'previous_project':{'maximum':5,'source_pdf_pages':[11]},'infrastructure':{'maximum':None,'source_pdf_pages':[12]},'department':{'maximum':None,'source_pdf_pages':[7]},'researcher':{'maximum':None,'source_pdf_pages':[9]},'main_contact':{'minimum':0,'maximum':1,'source_pdf_pages':[8,29,30,31],'note':'An affiliated entity in the source has no main-contact section; ordinary beneficiaries usually have one.'},'participant':{'minimum':1,'source_pdf_pages':[4]}},
 'fields':entries,
 'declarations':{'count':9,'required':True,'source_pdf_pages':[3]},
 'budget_rules':{
  'columns':'participant, personnel, subcontracting, purchase-travel, purchase-equipment, purchase-other, internally-invoiced, indirect, eligible-total, funding-rate, maximum-EU-contribution-to-eligible, requested-EU-contribution, max-grant, action-income, financial-contributions, own-resources, total-estimated-income',
  'ordinary_indirect_rule':'25 percent of eligible direct costs excluding subcontracting and internally invoiced goods/services; confirm call-specific exceptions.',
  'computed_columns':['indirect','total_eligible','maximum_eu_for_eligible','max_grant_amount','total_estimated_income'],
  'total_row':'aggregate monetary columns across participant records; do not sum funding_rate percentages',
  'source_pdf_pages':[194,195]
 }
}
(R/'schemas'/'fields.json').write_text(json.dumps(schema,indent=2,ensure_ascii=False)+'\n')
print('Generated schema fields:',len(entries))
