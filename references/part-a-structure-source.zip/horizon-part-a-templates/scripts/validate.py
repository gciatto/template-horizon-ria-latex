#!/usr/bin/env python3
"""Conservative Part A validator. Checks explicit constraints; not a portal emulator."""
from __future__ import annotations
import argparse
import json
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCHEMA=json.loads((ROOT/'schemas'/'fields.json').read_text())
QUESTIONS=json.loads((ROOT/'schemas'/'questions.json').read_text())
UNKNOWN={'','unanswered','unconfirmed','unknown','[todo]'}


def args_of(text: str, macro: str, n: int):
    """Parse `\\Macro{balanced}{arguments}` from a TeX source (basic literal grammar)."""
    needle='\\'+macro
    offset=0
    while (pos:=text.find(needle,offset)) >= 0:
        i=pos+len(needle)
        values=[]
        for _ in range(n):
            while i < len(text) and text[i].isspace():i+=1
            if i >= len(text) or text[i]!='{':break
            i+=1;start=i;depth=1
            while i<len(text) and depth:
                if text[i]=='\\' and i+1<len(text) and text[i+1] in '{}':
                    i+=2;continue
                if text[i]=='{':depth+=1
                elif text[i]=='}':depth-=1
                i+=1
            if depth:break
            values.append(text[start:i-1])
        if len(values)==n:
            yield (tuple(values), pos)
            offset=i
        else:
            offset=pos+len(needle)


def plain_text(s: str) -> str:
    """Estimate portal text from normal TeX input; not an arbitrary macro expander."""
    s=s.strip()
    s=re.sub(r'(?<!\\)%[^\n]*', '', s)
    s=re.sub(r'\\(?:emph|textbf|textit|underline)\{([^{}]*)\}',r'\1',s)
    s=re.sub(r'\\([&%$#_{}])',r'\1',s)
    s=s.replace('~',' ').replace('\\par','\n\n')
    # Physical source lines normally wrap words; blank lines denote paragraphs.
    paragraphs=re.split(r'\n\s*\n',s)
    return '\n\n'.join(re.sub(r'\s+',' ',p).strip() for p in paragraphs).strip()


def extract():
    files=[ROOT/'part-a-consortium.tex']
    files+=sorted((ROOT/'ethics').glob('*.tex'))
    files+=sorted((ROOT/'partners').glob('partner-*-admin-form.tex'))
    entries=[]; questions=[]; declarations=[]
    for file in files:
        contents=file.read_text(encoding='utf-8')
        contents=re.sub(r'(?m)^\s*%[^\n]*\n','',contents)
        for (key,value), pos in args_of(contents,'AField',2):
            entries.append((key,value,file,pos))
        for (key,label,answer,refs),pos in args_of(contents,'AQuestion',4):
            questions.append((key,answer,refs,file,pos))
        for (number,title,confirmed),pos in args_of(contents,'ADeclaration',3):
            declarations.append((number,confirmed,file,pos))
    return entries,questions,declarations,files


def validate(strict=False):
    errors=[];warnings=[]
    entries, questions, declarations, files=extract()
    bykey={}
    for key,raw,file,pos in entries:
        if key not in SCHEMA['fields']:
            errors.append(f'{file.relative_to(ROOT)}: unknown schema field {key}');continue
        field=SCHEMA['fields'][key]
        val=plain_text(raw)
        bykey.setdefault(key,[]).append(val)
        if val.lower() in UNKNOWN:continue
        limit=field.get('max_chars')
        if limit is not None and len(val)>limit:
            errors.append(f'{file.relative_to(ROOT)}: {key}: {len(val)} > {limit} characters (spaces included)')
        if field.get('forbidden_characters'):
            illegal=set(field['forbidden_characters']).intersection(val)
            if illegal: errors.append(f'{key}: forbidden characters: {sorted(illegal)}')
        ty=field['type']
        if ty=='boolean' and val.lower() not in ('yes','no','true','false'):
            errors.append(f'{key}: expected boolean yes/no, got {val!r}')
        if ty=='enum' and field.get('values') and val.lower() not in [str(x).lower() for x in field['values']]:
            errors.append(f'{key}: not in {field["values"]}: {val!r}')
        if ty=='multiselect':
            options={x.strip() for x in val.split(',')}
            if not options.issubset(field['values']):errors.append(f'{key}: invalid multiselect options {options-set(field["values"])}')
        if ty=='integer':
            try:n=int(val)
            except ValueError:errors.append(f'{key}: expected integer, got {val!r}');continue
            if str(n)!=val:errors.append(f'{key}: expected canonical integer, got {val!r}')
            if field.get('minimum') is not None and n<field['minimum']:errors.append(f'{key}: below minimum')
        if ty=='decimal':
            try:n=Decimal(val)
            except InvalidOperation:errors.append(f'{key}: expected decimal, got {val!r}');continue
            if not n.is_finite():errors.append(f'{key}: amount is non-finite')
            if field.get('minimum') is not None and n<field['minimum']:errors.append(f'{key}: below minimum')
            if field.get('maximum') is not None and n>field['maximum']:errors.append(f'{key}: above maximum')
            if field.get('precision') is not None and -n.as_tuple().exponent>field['precision']:
                errors.append(f'{key}: more than {field["precision"]} decimal digits')
        if ty=='email' and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',val):
            errors.append(f'{key}: malformed e-mail')
        if ty=='date' and not re.fullmatch(r'\d{2}/\d{2}/\d{4}',val):
            errors.append(f'{key}: expected DD/MM/YYYY')
        has_condition=bool(field.get('condition'))
        # For non-ORCID identifier types, the example does not reveal a regex.
        if field.get('pattern') and (not has_condition or not key.startswith('researcher.')) and not re.fullmatch(field['pattern'],val):
            errors.append(f'{key}: invalid identifier format')
        if '\\' in val:
            warnings.append(f'{key}: contains LaTeX commands; character count needs portal verification')
    for key,field in SCHEMA['fields'].items():
        if field.get('required') and (key not in bykey or all(v.lower() in UNKNOWN for v in bykey[key])):
            # Fields inside repeated record instances have contextual requiredness.
            if not key.startswith(('contact.','organisation.','participant.')):
                (errors if strict else warnings).append(f'{key}: required but not yet supplied')
    if strict:
        for field in ('contact.first_name','contact.last_name','contact.email','organisation.pic','organisation.legal_name'):
            if not any(v.lower() not in UNKNOWN for v in bykey.get(field,[])):
                errors.append(f'{field}: required for a complete partner entry')
    # Make question values available for conditional explanatory fields.
    for key,ans,_,_,_ in questions:bykey[key]=[ans]
    for condition_id,target_id in [('proposal.submitted_similar_last_2y','proposal.previous_reference'),('ethics.data.import','ethics.data.import.details'),('ethics.non_eu.activities','ethics.non_eu.activities.details'),('security.national_restrictions','security.national_restrictions.details'),('security.other','security.other.details')]:
        if any(v.lower()=='yes' for v in bykey.get(condition_id,[])) and not any(v.lower() not in UNKNOWN for v in bykey.get(target_id,[])):
            (errors if strict else warnings).append(f'{target_id}: needed when {condition_id} is yes')
    expected={x['id'] for x in QUESTIONS['ethics']+QUESTIONS['security']}
    found=[item[0] for item in questions]
    if set(found)!=expected: errors.append('Ethics/security question catalogue differs from TeX: missing='+repr(sorted(expected-set(found)))+' extra='+repr(sorted(set(found)-expected)))
    if len(found)!=len(set(found)):errors.append('Duplicate ethics/security question IDs')
    for key,ans,refs,_,_ in questions:
        if ans not in ('yes','no','unanswered'):errors.append(f'{key}: invalid answer {ans}')
        if refs.strip() and not re.fullmatch(r'\d+(\s*[,;-]\s*\d+)*',refs.strip()):
            errors.append(f'{key}: invalid Part B page references')
    nums=[x[0] for x in declarations]
    if sorted(nums)!=[str(i) for i in range(1,10)]:errors.append('Expected 9 declarations, numbered 1..9')
    if strict and any(yes.lower() not in ('yes','true') for _,yes,_,_ in declarations):
        errors.append('All 9 declarations require affirmative confirmation')
    # One canonical file per partner contains participant AND budget fields.
    # Both participant and budget compilation passes use the same manifest.
    partner_files = sorted((ROOT/'partners').glob('partner-*.tex'))
    manifest = (ROOT/'partners'/'participants.tex').read_text(encoding='utf-8')
    manifest_files = re.findall(r'(?m)^\\input\{partners/(partner-[^}]+\.tex)\}$', manifest)
    found_names = [f.name for f in partner_files]
    if len(set(manifest_files)) != len(manifest_files):
        errors.append('Partner manifest includes a file more than once')
    if set(found_names) != set(manifest_files):
        errors.append(f'Partner manifest mismatch: actual={sorted(found_names)}, referenced={sorted(manifest_files)}')
    partner_numbers=set()
    observed_order=[]
    for file in partner_files:
        filename = re.fullmatch(r'partner-([1-9]\d*)-([A-Z0-9]+(?:-[A-Z0-9]+)*)-admin-form\.tex', file.name)
        if not filename:
            errors.append(f'{file.name}: expected partner-N-ACRO-admin-form.tex')
            continue
        src = file.read_text(encoding='utf-8')
        fields={k:plain_text(v) for (k,v),_ in args_of(src,'AField',2)}
        number=fields.get('participant.number','')
        budget=fields.get('budget.participant_number','')
        prefix_number=int(filename.group(1))
        acronym=filename.group(2)
        if number!=str(prefix_number):
            errors.append(f'{file.name}: participant.number {number!r} differs from filename number {prefix_number}')
        if budget!=number:
            errors.append(f'{file.name}: budget.participant_number {budget!r} differs from participant.number {number!r}')
        if fields.get('organisation.short_name') != acronym:
            errors.append(f'{file.name}: organisation.short_name differs from filename acronym {acronym}')
        if number in partner_numbers:
            errors.append(f'{file.name}: duplicate participant.number {number}')
        partner_numbers.add(number)
        if src.count(r'\AParticipantData{') != 1 or src.count(r'\ABudgetData{') != 1:
            errors.append(f'{file.name}: expected one participant block and one budget block')
        if not re.search(r'\\begin\{ARecord\}\{budget_row\}',src):
            errors.append(f'{file.name}: budget_row record missing')
        if strict:
            for required in ['organisation.pic','organisation.legal_name','organisation.country']:
                if fields.get(required,'').lower() in UNKNOWN:
                    errors.append(f'{file.name}: missing {required}')
            if fields.get('participant.role','').lower()!='affiliated':
                match=re.search(r'\\begin\{ARecord\}\{main_contact\}(.*?)\\end\{ARecord\}',src,re.S)
                if not match:
                    errors.append(f'{file.name}: missing main_contact record')
                else:
                    main={k:plain_text(v) for (k,v),_ in args_of(match.group(1),'AField',2)}
                    for req in ['contact.first_name','contact.last_name','contact.email']:
                        if main.get(req,'').lower() in UNKNOWN:
                            errors.append(f'{file.name}: main contact missing {req}')
    for name in manifest_files:
        m = re.fullmatch(r'partner-([1-9]\d*)-[A-Z0-9]+(?:-[A-Z0-9]+)*-admin-form\.tex', name)
        if m: observed_order.append(int(m.group(1)))
    if observed_order != sorted(observed_order):
        errors.append(f'Partner manifest is not in participant number order: {observed_order}')
    if (ROOT/'budget').exists() and list((ROOT/'budget').glob('partner-*.tex')):
        errors.append('Old standalone partner budget files remain; move all partner fields into partners/')
    for file in (ROOT/'partners').glob('partner-*-admin-form.tex'):
        src=file.read_text()
        for name,limit in [('achievement',5),('previous_project',5)]:
            n=len(re.findall(r'\\begin\{ARecord\}\{'+name+r'\}',src))
            if n>limit:errors.append(f'{file.name}: {n} {name} records, max {limit}')
    # Budget is entered per entity; do not hard-code a global 100% rate.
    print(f'Checked {len(entries)} field occurrences, {len(questions)} questions, {len(declarations)} declarations across {len(files)} sources.')
    for msg in warnings:print('WARN:',msg)
    for msg in errors:print('ERROR:',msg)
    print(f'Result: {len(errors)} errors, {len(warnings)} warnings'+(' [strict]' if strict else ''))
    return 1 if errors else 0

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--strict',action='store_true',help='Reject uncompleted required fields and declarations')
    args=parser.parse_args()
    raise SystemExit(validate(args.strict))
