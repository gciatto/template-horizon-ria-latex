import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from validate import args_of,plain_text,QUESTIONS,SCHEMA
from decimal import Decimal
from budget_check import amt

class TestValidation(unittest.TestCase):
    def test_parses_nested_text(self):
        t=r'\AField{proposal.abstract}{Hello \emph{world} and \& stuff}'
        self.assertEqual(list(args_of(t,'AField',2))[0][0][0],'proposal.abstract')
    def test_count_spaces(self):
        self.assertEqual(len(plain_text('A single line with spaces')),25)
        self.assertEqual(len(plain_text('A sentence\nwrapped here')),23)
    def test_budget_indirect_example(self):
        # Coordinator row from source, p. 194: 957284+88000+140000+123000.
        base=sum(map(Decimal,['957284','88000','140000','123000']))
        self.assertEqual(amt(base*Decimal('0.25')),Decimal('327071.00'))
    def test_critical_bounds(self):
        f=SCHEMA['fields']
        for key,num in [('proposal.abstract',2000),('ethics.self_assessment.dimension',5000),('ethics.self_assessment.compliance',5000),('security.self_assessment',5000),('achievement.description',500),('previous_project.description',500),('infrastructure.description',300),('participant.other_role_specification',50),('security.national_restrictions.details',1000)]:
            self.assertEqual(f[key]['max_chars'],num)
            self.assertTrue(f[key]['count_spaces'])
    def test_question_count_and_uniqueness(self):
        questions=QUESTIONS['ethics']+QUESTIONS['security']
        self.assertEqual((len(QUESTIONS['ethics']),len(QUESTIONS['security'])),(33,5))
        self.assertEqual(len({q['id'] for q in questions}),len(questions))
if __name__=='__main__':unittest.main()
