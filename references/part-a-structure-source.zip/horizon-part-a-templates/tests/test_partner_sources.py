"""Regression tests for canonical single-file-per-partner data layout."""
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import add_partner as partner_tool
from validate import args_of, plain_text


class TestPartnerFileLayout(unittest.TestCase):
    def test_unpadded_canonical_filename(self):
        self.assertEqual(partner_tool.format_name(12, 'CnRs'), 'partner-12-CNRS-admin-form.tex')
        for number, acronym in ((0, 'UU'), (-4, 'UU'), (2, 'with spaces'), (2, 'invalid_underscore')):
            with self.subTest(number=number, acronym=acronym), self.assertRaises(ValueError):
                partner_tool.format_name(number, acronym)

    def test_one_source_contains_both_data_blocks(self):
        original = ROOT / 'partners' / 'partner-1-UNIBO-admin-form.tex'
        source = original.read_text(encoding='utf-8')
        self.assertEqual(source.count(r'\AParticipantData{'), 1)
        self.assertEqual(source.count(r'\ABudgetData{'), 1)
        keys = {key: plain_text(value) for (key, value), _ in args_of(source, 'AField', 2)}
        self.assertEqual(keys['participant.number'], '1')
        self.assertEqual(keys['budget.participant_number'], '1')
        self.assertEqual(keys['organisation.short_name'], 'UNIBO')
        self.assertIn(r'\begin{ARecord}{budget_row}', source)

    def test_creation_updates_one_manifest_in_numeric_order(self):
        with tempfile.TemporaryDirectory() as d:
            partners = Path(d)
            shutil.copy2(ROOT / 'partners' / 'partner-1-UNIBO-admin-form.tex', partners)
            with patch.object(partner_tool, 'PARTNERS', partners):
                partner_tool.update_manifest()
                p12 = partner_tool.add_partner(12, 'uni-12')
                p2 = partner_tool.add_partner(2, 'uu')
                self.assertEqual(p12.name, 'partner-12-UNI-12-admin-form.tex')
                self.assertEqual(p2.name, 'partner-2-UU-admin-form.tex')
                self.assertEqual(len(list(partners.glob('partner-*-admin-form.tex'))), 3)
                manifest = (partners / 'participants.tex').read_text()
                self.assertLess(manifest.find('partner-1-UNIBO'), manifest.find('partner-2-UU'))
                self.assertLess(manifest.find('partner-2-UU'), manifest.find('partner-12-UNI-12'))
                source = p2.read_text()
                fields = {key: plain_text(value) for (key, value), _ in args_of(source, 'AField', 2)}
                self.assertEqual(fields['participant.number'], '2')
                self.assertEqual(fields['budget.participant_number'], '2')
                self.assertEqual(fields['organisation.short_name'], 'UU')
                self.assertEqual(fields['participant.role'], 'partner')
                with self.assertRaises(ValueError):
                    partner_tool.add_partner(2, 'OTHER')

    def test_affiliated_partner_has_budget_without_main_contact(self):
        with tempfile.TemporaryDirectory() as d:
            partners = Path(d)
            shutil.copy2(ROOT / 'partners' / 'partner-1-UNIBO-admin-form.tex', partners)
            with patch.object(partner_tool, 'PARTNERS', partners):
                p = partner_tool.add_partner(4, 'cnrs', 'affiliated')
                src = p.read_text(encoding='utf-8')
                self.assertNotIn(r'\begin{ARecord}{main_contact}', src)
                self.assertIn(r'\begin{ARecord}{budget_row}', src)
                self.assertIn(r'\AField{participant.role}{affiliated}', src)


if __name__ == '__main__':
    unittest.main()
